#include "device.h"
#include "iostream"

using namespace std;

Device::Device()
{
}

Device::Device(int battery) : _batteryLife(battery)
	{
	}

void Device::ShowSpec()
	{
		cout << _batteryLife << "% battery" << endl;
	}

Device::~Device()
{
	cout << "Device destructed" << endl;
}


Player::Player()
{
}

Player::Player(std::string whatcolor) : colorPlayer(whatcolor)
{
}

Player::Player(int track, int battery, string whatcolor) : _totalTracks(track), _batteryLife(battery), colorPlayer(whatcolor)
{
}

void Player::ShowTotalTracks()
{
	cout << _totalTracks << " tracks can be save" << endl;
}

void Player::ShowSpec()
{
	cout << _batteryLife << "% battery in PLAYER" << endl << "Color player is: " << colorPlayer << endl << _totalTracks << " tracks" << endl;
}

Player::~Player()
{
	cout << "Player destructed" << endl;
}

Laptop::Laptop()
{
}

Laptop::Laptop(std::string color) : colorLaptop(color)
{
}

Laptop::Laptop(int bat, int sizeDisp, string color) : batteryLaptop(bat), sizeDisplay(sizeDisp), colorLaptop(color)
{
}

void Laptop::ShowSpec()
{
	cout << "Battery laptop: " << batteryLaptop << endl << "Display size: " << sizeDisplay << endl << "Color laptop: " << colorLaptop << endl;
}

Laptop::~Laptop()
{
	cout << "Laptop destructed" << endl;
}

RecoveryColorOnDevice::RecoveryColorOnDevice(std::string colorPlayer, std::string colorLaptop) : Player(colorPlayer), Laptop(colorLaptop)
{
}

void RecoveryColorOnDevice::ShowSpec()
{
	cout << "Player color: " << Player::colorPlayer << endl << "Laptop color: " << Laptop::colorLaptop << endl;
}

RecoveryColorOnDevice::~RecoveryColorOnDevice()
{
	cout << "RecoveryColorOnDevice destructed" << endl;
}