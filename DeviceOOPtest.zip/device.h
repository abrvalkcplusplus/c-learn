#pragma once
#include "string"
#include "IElectronics.h"



class Device : virtual public IElectronics
{
protected:
	int _batteryLife = 0;

public:
	Device();

	Device(int battery);

	virtual void ShowSpec() override;

	virtual ~Device();
};

class Player : virtual public Device
{
protected:
	int _batteryLife = 0;
	int _totalTracks = 0;
	std::string colorPlayer;

public:
	Player();
	Player(std::string whatcolor);
	Player(int track, int battery, std::string whatcolor);
	void ShowTotalTracks();
	void ShowSpec() override;
	~Player();
};

class Laptop : virtual public Device
{
protected:
	int batteryLaptop = 0;
	int sizeDisplay = 0;
	std::string colorLaptop;

public:
	Laptop();
	Laptop(std::string color);
	Laptop(int bat, int sizeDisp, std::string color);
	void ShowSpec() override;
	~Laptop();
};

class RecoveryColorOnDevice : public Player, Laptop
{
public:
	RecoveryColorOnDevice(std::string colorPlayer, std::string colorLaptop);
	void ShowSpec();
	~RecoveryColorOnDevice();
};