
#include "device.h"
#include "IElectronics.h"
#include "Appliances.h"
#include <iostream>

int main()
{
	setlocale(LC_ALL, "");

	IElectronics* store[5];

	store[0] = new Player(100, 1, "White");
	store[1] = new Laptop(15, 1000, "Black");
	store[2] = new Laptop(56, 6789, "Red");
	store[3] = new Player(1236, 95, "Blue");
	store[4] = new Player(1678, 100, "Grey");

	bool open = true;
	while(open)
		{
		std::cout << "�������� ������: �� 1 �� 5 ��� 0 ��� ������" << std::endl;
		int number = 0;
		std::cin >> number;
		switch (number)
		{
		case 1:
			store[0]->ShowSpec();
			break;
		case 2:
			store[1]->ShowSpec();
			break;
		case 3:
			store[2]->ShowSpec();
			break;
		case 4:
			store[3]->ShowSpec();
			break;
		case 5:
			store[4]->ShowSpec();
			break;
		case 0:
			open = false;
			break;
		}

		}


}





























//	none.ShowSpec();
//	Device* psony = &sony;
//	Device* pdevice = &none;
//	psony->ShowSpec();
//	pdevice->ShowSpec();

	//IElectronics* magaz[5];

	//magaz[0] = new Player(50, 100, "black");
	//magaz[1] = new Player(40, 60, "blue");
	//magaz[2] = new Player(30, 77, "yellow");
	//magaz[3] = new Player(2, 3, "white");
	//magaz[4] = new Player(11, 100, "red");

	//bool open = true;
	//while (open)

	//{
	//	cout << "�������� ������, 1,2,3,4,5 �� �����" << endl;
	//	int choise;
	//	cin >> choise;

	//	switch (choise)
	//	{
	//	case 1:
	//		magaz[0]->ShowSpec();
	//		open = false;
	//		break;

	//	case 2:
	//		magaz[1]->ShowSpec();
	//		open = false;
	//		break;

	//	case 3:
	//		magaz[2]->ShowSpec();
	//		open = false;
	//		break;

	//	case 4:
	//		magaz[3]->ShowSpec();
	//		open = false;
	//		break;

	//	case 5:
	//		magaz[4]->ShowSpec();
	//		open = false;
	//		break;

	//	case 0:
	//		open = false;
	//	break;

	//	}
	//}

