#pragma once

class IElectronics
{
public:
	virtual void ShowSpec() = 0;
	virtual ~IElectronics() = default;
};